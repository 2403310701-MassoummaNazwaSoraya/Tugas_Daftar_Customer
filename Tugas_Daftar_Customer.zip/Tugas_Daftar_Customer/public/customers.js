// public/customers.js

async function muatDataCustomer() {
    try {
        // Ambil data dari route Node.js: http://localhost:3000/db/customers
        const response = await fetch('/db/customers'); 
        
        if (!response.ok) {
            throw new Error(`Gagal fetch data: ${response.status}`);
        }
        
        const customers = await response.json(); // Array of customer objects

        const tbody = document.getElementById('data-customer');
        tbody.innerHTML = ''; 

       
        customers.forEach(customer => {
            const row = tbody.insertRow(); 
            
            
            row.insertCell().textContent = customer.cust_id;
            row.insertCell().textContent = customer.cust_name;
            row.insertCell().textContent = customer.cust_city;
        });

    } catch (error) {
        console.error("Terjadi error saat memuat data:", error);
       
        const tbody = document.getElementById('data-customer');
        tbody.innerHTML = `<tr><td colspan="3">Gagal memuat data. Cek server Node.js.</td></tr>`;
    }
}


muatDataCustomer();