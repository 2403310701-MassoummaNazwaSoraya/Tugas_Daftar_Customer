// index.js (di TUGAS_DAFTAR_CUSTOMER)

const express = require('express');
const mysql = require('mysql2'); 

const app = express();
const port = 3000; 
const hostname = '127.0.0.1'; 

// 1. KONFIGURASI KONEKSI KE db_toko
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root', 
    password: '', 
    database: 'db_toko' 
});

// Koneksi ke Database
conn.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL:', err.message);
    } else {
        console.log('Connected to the MySQL database (db_toko).');
    }
});

// Middleware untuk melayani file statis dari folder 'public'
app.use(express.static('public'));

// 2. ROUTE BARU: Mengambil semua data customers
app.get('/db/customers', (req, res) => {
    let sql = "SELECT * FROM customers";
    conn.query(sql, (err, result) => {
        if (err) {
            console.error("Error fetching data:", err);
            res.status(500).json({ error: "Failed to fetch data" });
        } else {
            res.json(result); // Kirim data sebagai JSON
        }
    });
});

// Jalankan Server
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}`);
});